package com.bezkoder.spring.jwt.mongodb.models;

public enum ERole {
  ROLE_VENDOR,
  ROLE_CUSTOMER,
  ROLE_ADMIN
}
